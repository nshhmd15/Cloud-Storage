$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

Write-Host "Building Cloud Storages..." -ForegroundColor Cyan
dotnet restore .\CloudStorages.sln
dotnet publish .\src\CloudStorages.App\CloudStorages.App.csproj -c Release -r win-x64 --self-contained true -o .\publish

$iss = Get-Command iscc.exe -ErrorAction SilentlyContinue
if ($iss) {
    & $iss.Source .\Installer\CloudStorages.iss
    Write-Host "Installer created in .\release" -ForegroundColor Green
} else {
    Write-Host "WinUI build completed in .\publish" -ForegroundColor Green
    Write-Host "Install Inno Setup, then run this script again to create Cloud-Storages-Setup.exe." -ForegroundColor Yellow
}
